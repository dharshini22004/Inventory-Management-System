import java.util.*;

class Product {
    String name;
    int id;
    int quantity;
    double price;

    public Product(int id, String name, int quantity, double price) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public void updateQuantity(int qty) {
        this.quantity += qty;
    }

    public String getProductDetails() {
        return "ID: " + id + ", Name: " + name + ", Quantity: " + quantity + ", Price: $" + price;
    }
}

class Inventory {
    private HashMap<Integer, Product> products;

    public Inventory() {
        products = new HashMap<>();
    }

    // Adds a new product to inventory
    public void addProduct(int id, String name, int quantity, double price) {
        Product product = new Product(id, name, quantity, price);
        products.put(id, product);
        System.out.println("Product added: " + product.getProductDetails());
    }

    // Sells a product if available in sufficient quantity
    public void sellProduct(int id, int quantity) {
        if (products.containsKey(id)) {
            Product product = products.get(id);
            if (product.quantity >= quantity) {
                product.updateQuantity(-quantity);
                System.out.println("Sold " + quantity + " of " + product.name);
            } else {
                System.out.println("Insufficient stock for product: " + product.name);
            }
        } else {
            System.out.println("Product not found!");
        }
    }

    // Displays all products in inventory
    public void displayProducts() {
        System.out.println("\nInventory List:");
        for (Product product : products.values()) {
            System.out.println(product.getProductDetails());
        }
    }

    // Gets details of a specific product by ID
    public void getProductDetails(int id) {
        if (products.containsKey(id)) {
            System.out.println("\nProduct Details:\n" + products.get(id).getProductDetails());
        } else {
            System.out.println("Product not found!");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventory inventory = new Inventory();

        while (true) {
            System.out.println("\nChoose an action:");
            System.out.println("1. Add Product");
            System.out.println("2. Sell Product");
            System.out.println("3. View All Products");
            System.out.println("4. Get Product Details");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1: {
                    System.out.print("Enter Product ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Product Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Product Quantity: ");
                    int quantity = scanner.nextInt();
                    System.out.print("Enter Product Price: ");
                    double price = scanner.nextDouble();
                    inventory.addProduct(id, name, quantity, price);
                    break;
                }
                case 2: {
                    System.out.print("Enter Product ID to Sell: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter Quantity to Sell: ");
                    int quantity = scanner.nextInt();
                    inventory.sellProduct(id, quantity);
                    break;
                }
                case 3: {
                    inventory.displayProducts();
                    break;
                }
                case 4: {
                    System.out.print("Enter Product ID to View: ");
                    int id = scanner.nextInt();
                    inventory.getProductDetails(id);
                    break;
                }
                case 5: {
                    System.out.println("Exiting the program...");
                    scanner.close();
                    return;
                }
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
